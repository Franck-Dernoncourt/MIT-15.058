YenKSP
======

Yen's K-Shortest Path Algorithm
Yen's algorithm computes single-source K-shortest loopless paths for a graph with non-negative edge cost. The algorithm was published by Jin Y. Yen in 1971 and implores any shortest path algorithm to find the best path, then proceeds to find K − 1 deviations of the best path. See also, <a href="http://en.wikipedia.org/wiki/Yen%27s_algorithm">Yen's Algorithm</a>.
